package eu.openiict.client.settings;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

import eu.openiict.client.R;

/**
 * Created by lmaroulis on 17/6/2015.
 */
public class NotificationsAdapter extends ArrayAdapter<NotificationItem> {

    Context context;
    int layoutResourceId;
    NotificationItem data[] = null;

    public NotificationsAdapter(Context context, int layoutResourceId, NotificationItem[] data) {
        super(context, layoutResourceId, data);
        this.context = context;
        this.layoutResourceId=layoutResourceId;
        this.data = data;
    }

    public void remove(int position){
        ArrayList<NotificationItem> tmp = new ArrayList<NotificationItem>(Arrays.asList(data));
        tmp.remove(position);
        data = tmp.toArray(new NotificationItem[tmp.size()]);
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return this.data.length;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        NotificationItemHolder holder = null;

        if(row == null)
        {
            LayoutInflater inflater = ((Activity)context).getLayoutInflater();
            row = inflater.inflate(layoutResourceId, parent, false);

            holder = new NotificationItemHolder();
            holder.from = (TextView)row.findViewById(R.id.tvFromApp);
            holder.type = (TextView)row.findViewById(R.id.tvType);
            holder.action = (TextView)row.findViewById(R.id.tvAction);
            holder.date = (TextView)row.findViewById(R.id.tvDate);

            row.setTag(holder);
        }
        else
        {
            holder = (NotificationItemHolder)row.getTag();
        }

        NotificationItem notificationItem = data[position];
        if(holder!=null && notificationItem!=null) {
            holder.from.setText(notificationItem.from);
            holder.type.setText(notificationItem.type);
            holder.action.setText(notificationItem.action);
            holder.date.setText(notificationItem.date);
        }

        return row;
    }

    static class NotificationItemHolder
    {
        TextView from;
        TextView date;
        TextView type;
        TextView action;
    }
}