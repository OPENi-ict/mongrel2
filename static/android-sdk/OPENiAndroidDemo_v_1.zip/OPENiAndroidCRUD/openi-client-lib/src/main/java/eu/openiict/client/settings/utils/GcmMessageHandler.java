package eu.openiict.client.settings.utils;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import eu.openiict.client.Properties;
import eu.openiict.client.R;
import eu.openiict.client.settings.NotificationItem;
import eu.openiict.client.settings.Notifications;
import eu.openiict.client.settings.NotificationsSQLiteHelper;

public class GcmMessageHandler extends IntentService {

    SharedPreferences prefs;
    NotificationCompat.Builder notification;
    NotificationManager manager;
    String mes;
    private Handler handler;
    private String datetopass;
    private String typetopass;

    public GcmMessageHandler() {
        super("GcmMessageHandler");
    }

    @Override
    public void onCreate() {
        // TODO Auto-generated method stub
        super.onCreate();
        handler = new Handler();
    }
    @Override
    protected void onHandleIntent(Intent intent) {
        Bundle extras = intent.getExtras();
        GoogleCloudMessaging gcm = GoogleCloudMessaging.getInstance(this);
        String messageType = gcm.getMessageType(intent);
        prefs = getSharedPreferences("Chat", 0);

        Log.i("GCM", "Received : (" +messageType+")  "+ extras);

        for (String key : extras.keySet())
        {
            Log.d("GCM", key + " = \"" + extras.get(key).toString() + "\"");
        }

        if (!extras.isEmpty()) {
            if (GoogleCloudMessaging.
                    MESSAGE_TYPE_SEND_ERROR.equals(messageType)) {
                Log.e("L2C", "Error");
            } else if (GoogleCloudMessaging.
                    MESSAGE_TYPE_DELETED.equals(messageType)) {
                Log.e("L2C", "Error");
            } else if (GoogleCloudMessaging.
                    MESSAGE_TYPE_MESSAGE.equals(messageType)) {
                if(!prefs.getString("CURRENT_ACTIVE","").equals(extras.getString("fromu"))) {
//                    sendNotification(extras.getString("cloudlet"), extras.getString("from"), extras.getString("value"));
                    if(extras.getString("type")!=null) {
                        sendNotification(extras.getString("from"),
                                extras.getString("collapse_key"),
                                extras.getString("object"),
                                extras.getString("type"),
                                extras.getString("date"),
                                extras.getString("cloudlet"));
                    }
                }
                Log.i("TAG", "Received: " + extras.getString("msg"));
            }
        }
        GcmBroadcastReceiver.completeWakefulIntent(intent);
    }

    // This function will create an intent. This intent must take as parameter the "unique_name" that you registered your activity with
    static void updateMyActivity(Context context, Bundle bundle) {
        Intent intent = new Intent("unique_name");
        //put whatever data you want to send, if any
        intent.putExtra("INFO", bundle);
        //send broadcast
        context.sendBroadcast(intent);
    }

    private void sendNotification(String from, String collapse_key, String object,
                                  String type, String date, String cloudlet) {
        Bundle args = new Bundle();
        args.putString("from", from);
        args.putString("collapse_key", collapse_key);
        args.putString("object", object);
        args.putString("type", type);
        args.putString("date", date);
        args.putString("cloudlet", cloudlet);
        String text = "from: " + from + ", type: " + type + ", date: " + date + ", cloudlet: " + cloudlet;
        Intent notif = new Intent(this, Notifications.class);
        notif.putExtra("INFO", args);

        long timestamp = Long.valueOf(date);
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);


        long last_timestamp = prefs.getLong("timestamp", -1);
        Log.e("LAST TIMESTAMP",String.valueOf(last_timestamp));
        if (last_timestamp<timestamp && !betweenRange(last_timestamp,timestamp-50,timestamp+50)) {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putLong("timestamp", timestamp);
            editor.commit();


            typetopass = type;
            datetopass = date;
            handler.post(new Runnable() {
                public void run() {
                    UpdateNotificationList(typetopass, datetopass);
                }
            });


            notification = new NotificationCompat.Builder(this);
            notification.setDefaults(Notification.DEFAULT_ALL);
            notification.setContentTitle(collapse_key);
            notification.setContentText(text);
            notification.setTicker(collapse_key);
            notification.setSmallIcon(R.drawable.ic_launcher);
            PendingIntent contentIntent = PendingIntent.getActivity(this, 1000,
                    notif, PendingIntent.FLAG_CANCEL_CURRENT);
            notification.setContentIntent(contentIntent);
            notification.setAutoCancel(true);
            manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            int notificationID = Properties.getInstance().getNotificationID();
            Notification notificationBuilt = notification.build();
            Properties.getInstance().addNotification(notificationBuilt);
            Log.d("notificationID: ", ": " + notificationID);
            manager.notify(notificationID, notificationBuilt);
            updateMyActivity(this, args);
//        handler.post(new DisplayToast(getApplicationContext(), "Hello World!"));
//        Toast.makeText(this, "This device is not supported", Toast.LENGTH_SHORT).show();
        }
    }

    public void showToast(){
        handler.post(new Runnable() {
            public void run() {
                Toast.makeText(getApplicationContext(), mes, Toast.LENGTH_LONG).show();
            }
        });

    }
    private void UpdateNotificationList(final String type,final String date){


        AsyncHttpClient client = new AsyncHttpClient();
        client.get(getApplicationContext(), Constants.BASE_URL + "/api/v1/types/"+ type,
                null,
                null,
                new AsyncHttpResponseHandler() {
                    @Override
                    public void onSuccess(int statusCode, org.apache.http.Header[] headers, byte[] responseBody) {
                        String response = new String(responseBody);
                        Log.i("--GOT TYPE",response);
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String type_name = jsonObject.getString("@reference");
                            Log.i("--GOT TYPE name",type_name);
                            Log.i("--GOT date",date);

                            NotificationsSQLiteHelper db = new NotificationsSQLiteHelper(getApplicationContext());
                            db.addNotificationItem(new NotificationItem("Openi Android",type_name, date ,"Create"));


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                    @Override
                    public void onFailure(int statusCode, org.apache.http.Header[] headers, byte[] responseBody, Throwable error) {
                            Log.e("onFailure",new String(responseBody));
                    }

                });


    }

    //to check timestamp and not send 2 notifications of the same time
    public static boolean betweenRange(long x, long min, long max)
    {
        return x>min && x<max;
    }
}
