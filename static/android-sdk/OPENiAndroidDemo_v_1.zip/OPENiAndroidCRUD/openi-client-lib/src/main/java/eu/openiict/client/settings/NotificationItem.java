package eu.openiict.client.settings;

import android.util.Log;

/**
 * Created by lmaroulis on 18/6/2015.
 */
public class NotificationItem {
    public int id;
    public String from;
    public String type;
    public String date;
    public String action;

    public  NotificationItem item;

    public NotificationItem(){super();}

    public NotificationItem(int id,String from, String type, String date, String action) {
        super();
        Log.i("from", from);
        this.id = id;
        this.from = from;
        this.type = type;
        this.date = date;
        this.action = action;
    }
    public NotificationItem(String from, String type, String date, String action) {
        super();
        Log.i("from", from);
        this.from = from;
        this.type = type;
        this.date = date;
        this.action = action;
    }
    public int getId(){return this.id;}
    public String getFrom(){return this.from;}
    public String getType(){return this.type;}
    public String getDate(){return this.date;}
    public String getAction(){return this.action;}

    public void setId(int id){ this.id=id;}
    public void setFrom(String from){ this.from=from;}
    public void setType(String type){ this.type =type;}
    public void setDate(String date){ this.date =date;}
    public void setAction(String action){ this.action =action;}


    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        String NEW_LINE = System.getProperty("line.separator");

        result.append(this.getClass().getName() + " Object {" + NEW_LINE);
        result.append(" Id: " + this.id + NEW_LINE );
        result.append(" Type: " + this.type + NEW_LINE );
        result.append(" From: " + this.from + NEW_LINE);
        result.append(" Date: " + this.date + NEW_LINE);
        result.append(" Action: " + this.action + NEW_LINE );

        result.append("}");

        return result.toString();
    }

}
