package eu.openi_ict.openiandroidcrud;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.util.Linkify;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import eu.openiict.client.api.ObjectsApi;
import eu.openiict.client.async.OPENiAsync;
import eu.openiict.client.async.models.ICloudletIdResponse;
import eu.openiict.client.async.models.ICloudletObjectResponse;
import eu.openiict.client.async.models.ICreateCloudletObjectResult;
import eu.openiict.client.async.models.IListObjectsResponse;
import eu.openiict.client.async.models.IOPENiAPiCall;
import eu.openiict.client.common.ApiException;
import eu.openiict.client.model.OPENiObject;
import eu.openiict.client.model.OPENiObjectList;
import eu.openiict.client.model.ObjectResponse;
import eu.openiict.client.settings.SettingsActivity;

/**
 * Created by Leonidas Maroulis on 28/05/15.
 */
public class MainActivity extends Activity implements View.OnClickListener {

   static final String TAG = "ANDROID SDK";

   private static Context applicationContext;

   private Button create;
   private Button create_one;
   private Button cloudlet;
   private Button list;
   private Button delete_all;
   private Button photo;
   private Button list_photo;
   private Button logout;
   private Button settings;


   private int i=0;

   private String TAG_TYPE  =  "t_cb064f54687902375d941d78bf166a3c-1422"; // "t_3b9dc0a1a64a9667ff1feae5056ec771-382";
   private String TAG_TYPE_PHOTO ="t_13d9404ad831f2ad50f6a255b0db185d-837";
   private String TAG_URL   =   "http://195.200.193.50:8888/assets/";

   private ArrayAdapter<String> arrayAdapter;
   private ArrayAdapter<String> names;

   private ProgressDialog progress;


   @Override
   protected void onCreate(Bundle savedInstanceState) {

      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_main);

      create = (Button) findViewById(R.id.create);
      create.setEnabled(true);
      create.setOnClickListener(this);

      create_one = (Button) findViewById(R.id.create_one);
      create_one.setEnabled(true);
      create_one.setOnClickListener(this);

      cloudlet = (Button) findViewById(R.id.cloudlet);
      cloudlet.setEnabled(true);
      cloudlet.setOnClickListener(this);

      list = (Button) findViewById(R.id.list);
      list.setOnClickListener(this);


      delete_all = (Button) findViewById(R.id.delete_all);
      delete_all.setOnClickListener(this);

      settings= (Button)findViewById(R.id.settings);
      settings.setOnClickListener(this);

        photo= (Button)findViewById(R.id.photo);
        photo.setOnClickListener(this);

       list_photo= (Button)findViewById(R.id.list_photo);
       list_photo.setOnClickListener(this);

       logout =(Button)findViewById(R.id.logout);
       logout.setOnClickListener(this);

      // startActivity(new Intent(this, eu.openiict.client.settings.PermissionsActivity.class));


   }

   @Override
   protected void onResume() {
      super.onResume();
       applicationContext = this;
      //Initialize Openi
      OPENiAsync.init(getResources().getString(R.string.api_key), getResources().getString(R.string.secret_key), applicationContext);
   }



   @Override
   public void onClick(View v) {
      progress = new ProgressDialog(this);
      progress.show();
      if (v.getId() == create.getId()) {
         createCloudletObjects();
      } else if (v.getId() == create_one.getId()) {
          i++;
          doAsyncCreateBanner("one_small_"+i+".jpg","one_big_"+i+".jpg", "name "+i, true);
      } else if (v.getId() == cloudlet.getId()) {
         readCloudLet();
      } else if (v.getId() == list.getId()) {
         listCloudletObjects();
      }else if (v.getId() == delete_all.getId()) {
          deleteallCloudletObjects(TAG_TYPE,false);
          deleteallCloudletObjects(TAG_TYPE_PHOTO,true);
      } else if (v.getId() == photo.getId()) {
          final Map data = new HashMap();
          data.put("width", "100px");
          data.put("height", "200px");
          doAsyncCreateObjectType(TAG_TYPE_PHOTO,data);
      }else if (v.getId() == list_photo.getId()) {
          listPhotoObjects();
      }else if (v.getId() == logout.getId()) {
          OPENiAsync.instance(this).logout();
          progress.dismiss();
      } else if (v.getId() == settings.getId()) {
          startSettings();
      }else {
         return;
      }
   }

   private void createCloudletObjects() {

       doAsyncCreateBanner("banner_health_fitness_young.jpg", "interstitial_health_fitness_young.jpg", "Health fitness young",false);
       doAsyncCreateBanner("banner_sports_young.jpg", "interstitial_sports_young.jpg", "Sports young" ,false);
       doAsyncCreateBanner("banner_health_fitness_family.jpg", "interstitial_health_fitness_family.jpg", "Health fitness family" ,false);
       doAsyncCreateBanner("banner_health_fitness_couple.jpg", "interstitial_health_fitness_couple.jpg", "Health fitness couple" ,false);
       doAsyncCreateBanner("banner_health_fitness_old.jpg", "interstitial_health_fitness_old.jpg", "Health fitness old" ,false);
       doAsyncCreateBanner("banner_sports_couple.jpg", "interstitial_sports_couple.jpg", "Sports couple" ,false);
       doAsyncCreateBanner("banner_sports_family.jpg", "interstitial_sports_family.jpg", "Sports family" ,false);
       doAsyncCreateBanner("banner_generic_hotel.jpg", "interstitial_generic_hotel.jpg", "Generic hotel" ,true);

   }

    /**
     * Function to get cloudlet id
     */
    public void readCloudLet(){
        OPENiAsync.instance(MainActivity.this).getCloudletID(new ICloudletIdResponse() {
            @Override
            public void onSuccess(String s) {
                progress.dismiss();
                Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
            }

            @Override
            public void onPermissionDenied() {
                progress.dismiss();
            }

            @Override
            public void onFailure(String s) {
                progress.dismiss();
            }
        });
    }


    public void startSettings(){
        OPENiAsync.instance(MainActivity.this).getCloudletID(new ICloudletIdResponse() {
            @Override
            public void onSuccess(String s) {
                progress.dismiss();
                startActivity(new Intent(getApplicationContext(), SettingsActivity.class));
            }

            @Override
            public void onPermissionDenied() {
                progress.dismiss();
            }

            @Override
            public void onFailure(String s) {
                progress.dismiss();
            }
        });
    }


    /**
     * Create a advertising banner (custom type)
     * @param small_banner
     * @param big_banner
     * @param Name
     */
    public void doAsyncCreateBanner(String small_banner,String big_banner,String Name, final boolean hideprogress){

        final OPENiObject oo = new OPENiObject();
        oo.setOpeniType(TAG_TYPE);
        final Map data = new HashMap();

/*      data.put("small_name", small_banner);
        data.put("big_name",big_banner);
        data.put("url", Url);*/

        data.put("banner_add", small_banner);
        data.put("banner_interstitial",big_banner);
        data.put("url", TAG_URL);

        //mock data
        data.put("object_type", "advertisement");
        data.put("name", Name);

        data.put("time", String.valueOf( Calendar.getInstance().getTimeInMillis() ));
        data.put("duration", "duration");

        data.put("adtype", new String[]{"1","2","3"});
        data.put("adnetwork", new String[]{});
        data.put("adservices", new String[]{});
        data.put("applications", new String[]{});
        data.put("criteria", new String[]{});



        oo.setData(data);

        OPENiAsync.instance(MainActivity.this).createCloudletObj(oo, new ICreateCloudletObjectResult() {

            @Override
            public void onSuccess(ObjectResponse objectResponse) {
                if (hideprogress) {
                    progress.dismiss();
                }
                Log.d("Success", "Created " + objectResponse.getId());
            }

            @Override
            public void onPermissionDenied() {
                progress.dismiss();
                Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(String s) {
                progress.dismiss();
                //Log.d(TAG, "Error: " + s);
                Toast.makeText(getApplicationContext(), "Failed to Create Object: "+s, Toast.LENGTH_SHORT).show();
            }

        });
    }

    /**
     * Create a object by type id (custom type)
     * @param type_id
     * @param data
     */
    public void doAsyncCreateObjectType(String type_id, final Map data){

        final OPENiObject oo = new OPENiObject();
        oo.setOpeniType(type_id);
        oo.setData(data);

        OPENiAsync.instance(MainActivity.this).createCloudletObj(oo, new ICreateCloudletObjectResult() {

            @Override
            public void onSuccess(ObjectResponse objectResponse) {
                progress.dismiss();
                Log.d("Success", "Created " + objectResponse.getId());
            }

            @Override
            public void onPermissionDenied() {
                progress.dismiss();
                Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(String s) {
                progress.dismiss();
                //Log.d(TAG, "Error: " + s);
                Toast.makeText(getApplicationContext(), "Failed to Create Object: "+s, Toast.LENGTH_SHORT).show();
            }

        });
    }


    /**
     * List all cloudlet objects (based on type id)
     */
   private void listCloudletObjects() {

      arrayAdapter = new ArrayAdapter<String>(MainActivity.this,  android.R.layout.select_dialog_singlechoice);

      names = new ArrayAdapter<String>(MainActivity.this,  android.R.layout.select_dialog_singlechoice);


       OPENiAsync.instance(applicationContext).listCloudletObjects(null, null, TAG_TYPE, false, null, null, null, new IListObjectsResponse() {

         @Override
         public void onSuccess(OPENiObjectList openiObjectList) {
            progress.dismiss();


            String message = "Found " + openiObjectList.getMeta().getTotalCount() + " advertising objects in this cloudlet";
            // Log.e("message",message);
             Toast.makeText(getApplicationContext(),message,Toast.LENGTH_SHORT).show();

             List<OPENiObject> list = openiObjectList.getResult();
             Collections.sort(list , new Comparator<OPENiObject>() {
                 public int compare(OPENiObject o1, OPENiObject o2) {
                     //Sorts by 'DateCreated' property DESC
                     Log.e(TAG,o1.getDateCreated().toString());
                     return o2.getDateCreated().compareTo(o1.getDateCreated());
                 }
             });

            for (OPENiObject oo : list) {

               message += oo.getId() + "\n ";
               names.add(oo.getData().get("name").toString());

               arrayAdapter.add(oo.getId());
            }
             ShowListDialog(arrayAdapter,names);
         }

         @Override
         public void onPermissionDenied() {
            progress.dismiss();
            Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
         }

         @Override
         public void onFailure(String s) {
            progress.dismiss();
            Toast.makeText(getApplicationContext(), "Failed to Get Objects: "+s, Toast.LENGTH_SHORT).show();
         }

      });
   }

    private void listPhotoObjects() {

        arrayAdapter = new ArrayAdapter<String>(MainActivity.this,  android.R.layout.select_dialog_singlechoice);

        names = new ArrayAdapter<String>(MainActivity.this,  android.R.layout.select_dialog_singlechoice);


        OPENiAsync.instance(applicationContext).listCloudletObjects(null, null, TAG_TYPE_PHOTO, false, null, null, null, new IListObjectsResponse() {

            @Override
            public void onSuccess(OPENiObjectList openiObjectList) {
                progress.dismiss();


                String message = "Found " + openiObjectList.getMeta().getTotalCount() + " photo objects in this cloudlet";
                // Log.e("message",message);
                Toast.makeText(getApplicationContext(),message,Toast.LENGTH_SHORT).show();

                List<OPENiObject> list = openiObjectList.getResult();
                Collections.sort(list , new Comparator<OPENiObject>() {
                    public int compare(OPENiObject o1, OPENiObject o2) {
                        //Sorts by 'DateCreated' property DESC
                        Log.e(TAG,o1.getDateCreated().toString());
                        return o2.getDateCreated().compareTo(o1.getDateCreated());
                    }
                });

                for (OPENiObject oo : list) {

                    message += oo.getId() + "\n ";
                    names.add(oo.getDateCreated().toString());

                    //Log.e("Tag",oo.getLocation().toString());
                    arrayAdapter.add(oo.getId());
                }

                //ShowListDialog(arrayAdapter,names);
                ShowListDialogPhoto(arrayAdapter,names);
            }

            @Override
            public void onPermissionDenied() {
                progress.dismiss();
                Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(String s) {
                progress.dismiss();
                Toast.makeText(getApplicationContext(), "Failed to Get Objects: "+s, Toast.LENGTH_SHORT).show();
            }

        });
    }

    /**
     * Delete all cloudlet objects by TYPE ID
     */
    private void deleteallCloudletObjects(String type, final boolean hide_progress) {

        OPENiAsync.instance(applicationContext).listCloudletObjects(null, null, type, false, null, null, null, new IListObjectsResponse() {

            @Override
            public void onSuccess(OPENiObjectList openiObjectList) {
                progress.dismiss();

                for (OPENiObject oo : openiObjectList.getResult()) {
                    doDelete(oo.getId(),hide_progress);
                }

            }

            @Override
            public void onPermissionDenied() {
                progress.dismiss();
                Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(String s) {
                progress.dismiss();
                //Log.d(TAG, "Error: " + s);
                Toast.makeText(getApplicationContext(), "Failed to Get Objects: "+s, Toast.LENGTH_SHORT).show();
            }

        });

    }

    /**
     * Delete cloudlet object based on object id
     * @param obj_id
     */
    public void doDelete(final String obj_id, final boolean hide_progress){
        OPENiAsync.instance(applicationContext).execOpeniApiCall(new IOPENiAPiCall() {
            @Override
            public Object doProcess(String auth) {

                ObjectResponse responce = null;

                try {
                    return new ObjectsApi().removeObjectByAuth(obj_id, auth);
                } catch (ApiException e) {
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            public void onSuccess(Object o) {
                if(hide_progress) {
                    progress.dismiss();
                }
                //Toast.makeText(getApplicationContext(), "Deleted: " + o.toString(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPermissionDenied() {
                progress.dismiss();
                Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(String s) {
                progress.dismiss();
                //Log.d(TAG, "Error: " + s);
                Toast.makeText(getApplicationContext(), "Failed to Delete Object: "+s, Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Show list with all available objects
     * @param arrayAdapter
     */
    public void ShowListDialog( final ArrayAdapter<String> arrayAdapter, final ArrayAdapter<String> namesAdapter){
        if(arrayAdapter.isEmpty()){
            Toast.makeText(getApplicationContext(),"No objects in cloudlet",Toast.LENGTH_LONG).show();
            return;
        }
        AlertDialog.Builder builderSingle = new AlertDialog.Builder(
                MainActivity.this);
        builderSingle.setIcon(R.drawable.ic_launcher);
        builderSingle.setTitle("List With All Advertising Objects");

        builderSingle.setNegativeButton("cancel",
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        builderSingle.setAdapter(namesAdapter,
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final String objid = arrayAdapter.getItem(which);
                        final AlertDialog.Builder builderInner = new AlertDialog.Builder(
                                MainActivity.this, R.style.AlertDialogCustom);
                        progress.show();
                        OPENiAsync.instance(applicationContext).getCloudletObject(objid, new ICloudletObjectResponse() {

                            @Override
                            public void onSuccess(OPENiObject openiObject) {
                                progress.dismiss();

                                ScrollView scrollView = new ScrollView(MainActivity.this);
                                TextView tv_message = new TextView(MainActivity.this);
                                tv_message.setAutoLinkMask(Linkify.WEB_URLS);
                                tv_message.setText(Html.fromHtml(
                                        "<u><b>Name: " + openiObject.getData().get("name") +"</b></u>"
                                        + "<br><b>Object type:</b> " + openiObject.getData().get("object_type")
                                        +"<br><br><b>Object id:</b> " + openiObject.getId().toString()
                                        + "<br><b>Cloudlet:</b> " + openiObject.getCloudlet()
                                        + "<br><b>Time:</b> " + openiObject.getData().get("time")
                                        + "<br><b>Duration:</b> " + openiObject.getData().get("duration")
                                        + "<br><b>Adtype:</b> " + openiObject.getData().get("adtype")
                                        + "<br><b>Adnetwork:</b> " + openiObject.getData().get("adnetwork")
                                        + "<br><b>Adservices:</b> " + openiObject.getData().get("adservices")
                                        + "<br><b>Applications:</b> " + openiObject.getData().get("applications")
                                        + "<br><b>Criteria:</b> " + openiObject.getData().get("criteria")

                                        + "<br><br><b>banner_interstitial:</b> " + openiObject.getData().get("banner_interstitial")
                                        + "<br><b>banner_add:</b>" + openiObject.getData().get("banner_add")
                                        + "<br><b>url:</b> " + openiObject.getData().get("url")
                                ));

                                Log.i(TAG,openiObject.getData().get("time").toString());

                                scrollView.addView(tv_message);
                                builderInner.setView(scrollView);
                                builderInner.setTitle("Your Selected Object is");
                                builderInner.setPositiveButton("Close",
                                        new DialogInterface.OnClickListener() {

                                            @Override
                                            public void onClick(
                                                    DialogInterface dialog,
                                                    int which) {
                                                dialog.dismiss();
                                            }
                                        });
                                builderInner.setNegativeButton("Delete",
                                        new DialogInterface.OnClickListener() {

                                            @Override
                                            public void onClick(
                                                    DialogInterface dialog,
                                                    int which) {
                                                progress.show();
                                                doDelete(objid,true);
                                            }
                                        });
                                builderInner.show();
                            }

                            @Override
                            public void onPermissionDenied() {
                                progress.dismiss();
                                builderInner.setMessage("Permission Denied");
                                builderInner.setTitle("Your Selected Object is");
                                builderInner.setPositiveButton("Ok",
                                        new DialogInterface.OnClickListener() {

                                            @Override
                                            public void onClick(
                                                    DialogInterface dialog,
                                                    int which) {
                                                dialog.dismiss();
                                            }
                                        });
                                builderInner.show();
                            }

                            @Override
                            public void onFailure(String s) {
                                progress.dismiss();
                                builderInner.setMessage("Failed: " + s);
                                builderInner.setTitle("Your Selected Object is");
                                builderInner.setPositiveButton("Ok",
                                        new DialogInterface.OnClickListener() {

                                            @Override
                                            public void onClick(
                                                    DialogInterface dialog,
                                                    int which) {
                                                dialog.dismiss();
                                            }
                                        });
                                builderInner.show();
                            }
                        });

                    }
                });
        builderSingle.show();
    }


    public void ShowListDialogPhoto( final ArrayAdapter<String> arrayAdapter, final ArrayAdapter<String> namesAdapter){
        if(arrayAdapter.isEmpty()){
            Toast.makeText(getApplicationContext(),"No objects in cloudlet",Toast.LENGTH_LONG).show();
            return;
        }
        AlertDialog.Builder builderSingle = new AlertDialog.Builder(
                MainActivity.this);
        builderSingle.setIcon(R.drawable.ic_launcher);
        builderSingle.setTitle("List With All Photo Objects");

        builderSingle.setNegativeButton("cancel",
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        builderSingle.setAdapter(namesAdapter,
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final String objid = arrayAdapter.getItem(which);
                        final AlertDialog.Builder builderInner = new AlertDialog.Builder(
                                MainActivity.this, R.style.AlertDialogCustom);
                        progress.show();
                        OPENiAsync.instance(applicationContext).getCloudletObject(objid, new ICloudletObjectResponse() {

                            @Override
                            public void onSuccess(OPENiObject openiObject) {
                                progress.dismiss();

                                ScrollView scrollView = new ScrollView(MainActivity.this);
                                TextView tv_message = new TextView(MainActivity.this);
                                tv_message.setAutoLinkMask(Linkify.WEB_URLS);
                                tv_message.setText(Html.fromHtml(
                                        "<u><b>Id: " + openiObject.getId() +"</b></u>"
                                                + "<br><b>Object type:</b> " + openiObject.getOpeniType()
                                                + "<br><b>Cloudlet:</b> " + openiObject.getCloudlet()
                                                + "<br><b>Time:</b> " + openiObject.getDateCreated()


                                                + "<br><br><b>Width: </b> " + openiObject.getData().get("width")
                                                + "<br><b>Height: </b>" + openiObject.getData().get("height")
                                                + "<br><b>Location: </b> " + openiObject.getLocation()
                                ));

                                //Log.i(TAG,openiObject.getData().get("time").toString());

                                scrollView.addView(tv_message);
                                builderInner.setView(scrollView);
                                builderInner.setTitle("Your Selected Object is");
                                builderInner.setPositiveButton("Close",
                                        new DialogInterface.OnClickListener() {

                                            @Override
                                            public void onClick(
                                                    DialogInterface dialog,
                                                    int which) {
                                                dialog.dismiss();
                                            }
                                        });
                                builderInner.setNegativeButton("Delete",
                                        new DialogInterface.OnClickListener() {

                                            @Override
                                            public void onClick(
                                                    DialogInterface dialog,
                                                    int which) {
                                                progress.show();
                                                doDelete(objid,true);
                                            }
                                        });
                                builderInner.show();
                            }

                            @Override
                            public void onPermissionDenied() {
                                progress.dismiss();
                                builderInner.setMessage("Permission Denied");
                                builderInner.setTitle("Your Selected Object is");
                                builderInner.setPositiveButton("Ok",
                                        new DialogInterface.OnClickListener() {

                                            @Override
                                            public void onClick(
                                                    DialogInterface dialog,
                                                    int which) {
                                                dialog.dismiss();
                                            }
                                        });
                                builderInner.show();
                            }

                            @Override
                            public void onFailure(String s) {
                                progress.dismiss();
                                builderInner.setMessage("Failed: " + s);
                                builderInner.setTitle("Your Selected Object is");
                                builderInner.setPositiveButton("Ok",
                                        new DialogInterface.OnClickListener() {

                                            @Override
                                            public void onClick(
                                                    DialogInterface dialog,
                                                    int which) {
                                                dialog.dismiss();
                                            }
                                        });
                                builderInner.show();
                            }
                        });

                    }
                });
        builderSingle.show();
    }

}
