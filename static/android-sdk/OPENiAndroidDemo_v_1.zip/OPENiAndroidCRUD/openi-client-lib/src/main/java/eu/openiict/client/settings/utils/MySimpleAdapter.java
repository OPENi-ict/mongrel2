package eu.openiict.client.settings.utils;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import eu.openiict.client.R;

public class MySimpleAdapter extends ArrayAdapter<String> {
    private final Context context;
    public MySimpleAdapter(Context context, int textViewResourceId) {
        super(context, textViewResourceId);
        this.context = context;
    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.notification, parent, false);
        TextView textView = (TextView) rowView.findViewById(R.id.list_item);
        textView.setText("000000");
//        textView.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                Log.d(">>>>>", "qwerty");
//            }
//        });
        return rowView;
    }
}