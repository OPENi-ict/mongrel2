package eu.openiict.client.settings.utils;

/**
 * Created by lmaroulis on 11/6/2015.
 */
public  class Constants {
    public static String API_KEY = "81693dfdc4041d0fc0432d5af07a428e";
    public static String BASE_URL = "https://demo2.openi-ict.eu:443";

    public static String ALERT_PREFIX = "alert_";

}
