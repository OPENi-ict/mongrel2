package eu.openiict.client.settings;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.gcm.GoogleCloudMessaging;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import eu.openiict.client.R;

public class Notifications extends ListActivity {

    private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    String SENDER_ID = "844481426265";//"577101183835";//"844481426265";
    static final String TAG = "Notifications";
    GoogleCloudMessaging gcm;
    SharedPreferences prefs;
    Context context;
    String regid;
    NotificationsAdapter adapter;
    NotificationItem ItemData[];
    private NotificationsSQLiteHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification_main);
        prefs = getSharedPreferences("Chat", 0);
        context = getApplicationContext();
        if(checkPlayServices()){
            new Register().execute();
        }else{
            Toast.makeText(getApplicationContext(), "This device is not supported",
                    Toast.LENGTH_SHORT).show();
        }

/*        SharedPreferences DataForList = getSharedPreferences("DataForList", MODE_PRIVATE);
        // Reading from SharedPreferences
        String value = DataForList.getString("jsonData", "");
        Log.e(TAG,value);
        SharedPreferences prefs = getSharedPreferences("DataForList", MODE_PRIVATE);
        Set<String> listJsonSet = prefs
                .getStringSet("jsonList", new TreeSet<String>());
        List<String> listJson = new ArrayList<String>(listJsonSet);
        Log.e(TAG,String.valueOf(listJson.size()));
        Log.e(TAG,String.valueOf(listJson.toString()));
    */

        db = new NotificationsSQLiteHelper(this);
        List<NotificationItem> notificationItemList = db.getLastTenNotificationItems();
        Log.e(TAG,String.valueOf(notificationItemList.size()));

        NotificationItem notificationItemData[] = new NotificationItem[notificationItemList.size()];
        this.ItemData= notificationItemData;

        for (int i=0;i<notificationItemList.size();i++){
            Log.e(TAG,String.valueOf(notificationItemList.get(i).toString()));
            notificationItemData[i] = new NotificationItem(
                    notificationItemList.get(i).getId(),
                    notificationItemList.get(i).getFrom(),
                    notificationItemList.get(i).getType(),
                    getDateCurrentTimeZone(notificationItemList.get(i).getDate()),
                    notificationItemList.get(i).getAction());
        }


        Bundle bundle = getIntent().getBundleExtra("INFO");
        if(bundle!=null){
               Log.e(TAG,bundle.getString("from"));
        }


        if(notificationItemList.size()>0) {
            adapter = new NotificationsAdapter(this, R.layout.notifications_listview_item_row, ItemData);
            setListAdapter(adapter);
        }

       // adapter=new ArrayAdapter<String>(this,
       //         android.R.layout.simple_list_item_1,
       //         listItems);
       // setListAdapter(adapter);
    }

    public  String getDateCurrentTimeZone(String timestamp) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeZone(TimeZone.getDefault());
        cal.setTimeInMillis(Long.parseLong(timestamp));
        return (cal.get(Calendar.DAY_OF_MONTH) + "/" + (cal.get(Calendar.MONTH) + 1) + "/" + cal.get(Calendar.YEAR)
                + " - " + String.format("%02d", cal.get(Calendar.HOUR_OF_DAY)) + ":"
                + String.format("%02d", cal.get(Calendar.MINUTE)));
    }

    private boolean checkPlayServices() {
        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode, this,
                        PLAY_SERVICES_RESOLUTION_REQUEST).show();
            } else {
                Log.i(TAG, "This device is not supported.");
                finish();
            }
            return false;
        }
        return true;
    }

    private class Register extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... args) {
            try {
                if (gcm == null) {
                    gcm = GoogleCloudMessaging.getInstance(getApplicationContext());
                    regid = gcm.register(SENDER_ID);
                    Log.d("RegId",regid);
                    SharedPreferences.Editor edit = prefs.edit();
                    edit.putString("REG_ID", regid);
                    edit.commit();
                    Log.d("gcm", "regId: " + regid);
                }
                return  regid;
            } catch (IOException ex) {
                Log.d("error", "gcm error");
                Log.e("Error", ex.getMessage());
                return "Fails";
            }
        }
        @Override
        protected void onPostExecute(String json) { }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

/*    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getBundleExtra("INFO");
            String from = bundle.getString("from");
            String collapseKey = bundle.getString("collapse_key");
            String object = bundle.getString("object");
            String type = bundle.getString("type");
            String date = bundle.getString("date");
            String cloudlet = bundle.getString("cloudlet");
            Log.d(TAG, from);
            Log.d(TAG, collapseKey);
            Log.d(TAG, object);
            Log.d(TAG, type);
            Log.d(TAG, date);
            Log.d(TAG, cloudlet);
            String itemContent = "from: " + from + ", object: " + object + ", type: " + type
                    + ", date: " + date + ", cloudlet: " + cloudlet;
            listItems.add(itemContent);
            adapter.notifyDataSetChanged();
        }
    };*/

    @Override
    public void onResume() {
        super.onResume();
        //context.registerReceiver(mMessageReceiver, new IntentFilter("unique_name"));
    }

    @Override
    protected void onPause() {
        super.onPause();
        //context.unregisterReceiver(mMessageReceiver);
    }

    @Override
    protected void onListItemClick(ListView l, View v, final int position, long id) {
        //listItems.remove(position);
        //adapter.notifyDataSetChanged();
        //Log.i(TAG, String.valueOf(ItemData[position].getId()));
        final int i = position;
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case DialogInterface.BUTTON_POSITIVE:
                        db.deleteNotificationItem(ItemData[i]);
                        adapter.remove(i);
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        dialog.dismiss();
                        break;
                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(Notifications.this);
        builder.setMessage("Do you want to delete from list?").setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();
    }



}