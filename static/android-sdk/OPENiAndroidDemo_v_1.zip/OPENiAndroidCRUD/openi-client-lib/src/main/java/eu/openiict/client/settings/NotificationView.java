package eu.openiict.client.settings;

import android.app.Activity;
import android.os.Bundle;

import eu.openiict.client.R;

public class NotificationView extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification);
    }

}