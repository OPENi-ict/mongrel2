package eu.openiict.client;

import android.app.Notification;
import android.util.Log;

import java.util.HashMap;

public class Properties {

    private static Properties mInstance= null;
    private final static int MAX_NOTIFICATIONS = 10;
    private HashMap<Integer, Notification> notifications = new HashMap<Integer, Notification>();
    private Integer currentNotificationIndex = new Integer(-1);
    private int notificationID = 0;

    protected Properties(){}

    public int getNotificationID() {
        notificationID = notificationID + 1;
        return notificationID;
    }

    public static synchronized Properties getInstance(){
        if(null == mInstance){
            mInstance = new Properties();
        }
        return mInstance;
    }

    public void addNotification(Notification notification) {
        Log.d("cni: ", "" + currentNotificationIndex);
        currentNotificationIndex = currentNotificationIndex + new Integer(1);
        Log.d("cni: ", "" + currentNotificationIndex);
        if (currentNotificationIndex >= new Integer (MAX_NOTIFICATIONS )) {
            currentNotificationIndex = new Integer(0);
        }
        Log.d("cni: ", "" + currentNotificationIndex);
        notifications.put(currentNotificationIndex, notification);
        Log.d("size: ", "" + notifications.size());
    }

    public HashMap<Integer, Notification> getNotifications() {
        return notifications;
    }

}