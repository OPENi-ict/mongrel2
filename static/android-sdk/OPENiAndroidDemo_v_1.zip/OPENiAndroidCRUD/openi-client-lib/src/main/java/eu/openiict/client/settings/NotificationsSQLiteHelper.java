package eu.openiict.client.settings;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by lmaroulis on 18/6/2015.
 */
public class NotificationsSQLiteHelper  extends SQLiteOpenHelper{
    // Database Version
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "NotificationsDB";

    // Books table name
    private static final String TABLE_NOTIFICATIONS = "notificationItems";

    // Books Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_APP = "app";
    private static final String KEY_DATE = "date";
    private static final String KEY_ACTION = "action";
    private static final String KEY_TYPE = "type";


    private static final String[] COLUMNS = {KEY_ID,KEY_APP,KEY_DATE,KEY_ACTION,KEY_TYPE};

    public NotificationsSQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL statement to create book table
        String CREATE_NOTIFICATIONS_TABLE = "CREATE TABLE notificationItems ( " +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "app TEXT, "+
                "date TEXT, "+
                "action TEXT, "+
                "type TEXT )";

        // create books table
        db.execSQL(CREATE_NOTIFICATIONS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older books table if existed
        db.execSQL("DROP TABLE IF EXISTS notificationItems");

        // create fresh books table
        this.onCreate(db);
    }

    public void addNotificationItem(NotificationItem item){
        //for logging
        Log.d("addNotificationItem", item.toString());

        // 1. get reference to writable DB
         SQLiteDatabase db = this.getWritableDatabase();

        // 2. create ContentValues to add key "column"/value
        ContentValues values = new ContentValues();
        values.put(KEY_APP, item.getFrom());
        values.put(KEY_DATE, item.getDate());
        values.put(KEY_ACTION, item.getAction());
        values.put(KEY_TYPE, item.getType());

        // 3. insert
        db.insert(TABLE_NOTIFICATIONS, // table
                null, //nullColumnHack
                values); // key/value -> keys = column names/ values = column values

        // 4. close
        db.close();
    }

    public List<NotificationItem> getAllNotificationItems() {
        List<NotificationItem> notificationItems = new LinkedList<NotificationItem>();

        // 1. build the query
        String query = "SELECT  * FROM " + TABLE_NOTIFICATIONS ;

        // 2. get reference to writable DB
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        // 3. go over each row, build book and add it to list
        NotificationItem notificationItem = null;
        if (cursor.moveToFirst()) {
            do {
                notificationItem = new NotificationItem();
                notificationItem.setId(Integer.parseInt(cursor.getString(0)));
                notificationItem.setFrom(cursor.getString(1));
                notificationItem.setDate(cursor.getString(2));
                notificationItem.setAction(cursor.getString(3));
                notificationItem.setType(cursor.getString(4));

                // Add book to books
                notificationItems.add(notificationItem);
            } while (cursor.moveToNext());
        }

        Log.d("getAllNotifications()", notificationItems.toString());

        // return books
        return notificationItems;
    }

    public List<NotificationItem> getLastTenNotificationItems() {
        List<NotificationItem> notificationItems = new LinkedList<NotificationItem>();

        // 1. build the query
        String query = "SELECT  * FROM " + TABLE_NOTIFICATIONS + " ORDER BY "+KEY_ID+" DESC LIMIT 10 ";



        // 2. get reference to writable DB
        SQLiteDatabase db = this.getWritableDatabase();



        String delete_rest_records_query =
                "DELETE FROM "+TABLE_NOTIFICATIONS + " WHERE "+KEY_ID+" NOT IN ("+
                            "SELECT  "+KEY_ID+" " +
                            "FROM " + TABLE_NOTIFICATIONS + " " +
                            "ORDER BY "+KEY_ID+" " +
                            "DESC LIMIT 10 " +
                ")";

        db.rawQuery(delete_rest_records_query, null).moveToFirst();

        Cursor cursor = db.rawQuery(query, null);

        long count = DatabaseUtils.queryNumEntries(db, TABLE_NOTIFICATIONS, null, null);
        Log.i("total: ",String.valueOf(count));

        // 3. go over each row, build book and add it to list
        NotificationItem notificationItem = null;
        if (cursor.moveToFirst()) {
            do {
                notificationItem = new NotificationItem();
                notificationItem.setId(Integer.parseInt(cursor.getString(0)));
                notificationItem.setFrom(cursor.getString(1));
                notificationItem.setDate(cursor.getString(2));
                notificationItem.setAction(cursor.getString(3));
                notificationItem.setType(cursor.getString(4));

                // Add book to books
                notificationItems.add(notificationItem);
            } while (cursor.moveToNext());
        }

        Log.d("getAllNotifications()", notificationItems.toString());

        // return books
        return notificationItems;
    }

    public void deleteNotificationItem(NotificationItem notificationItem) {

        // 1. get reference to writable DB
        SQLiteDatabase db = this.getWritableDatabase();

        // 2. delete
        db.delete(TABLE_NOTIFICATIONS, //table name
                KEY_ID+" = ?",  // selections
                new String[] { String.valueOf(notificationItem.getId()) }); //selections args

        // 3. close
        db.close();

        //log
        Log.d("deleteNotification", notificationItem.toString());

    }

}
