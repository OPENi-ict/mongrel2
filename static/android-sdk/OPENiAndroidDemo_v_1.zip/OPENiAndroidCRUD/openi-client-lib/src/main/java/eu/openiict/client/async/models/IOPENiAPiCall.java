package eu.openiict.client.async.models;

/**
 * Created by dmccarthy on 16/11/14.
 */
public interface IOPENiAPiCall<ProcessObject> {

    public ProcessObject doProcess(String authToken);

    public void onSuccess(Object object);

    public void onPermissionDenied();

    public void onFailure(String message);

}
