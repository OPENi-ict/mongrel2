package eu.openiict.client.settings.utils;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;

import java.io.InputStream;

public class PermissionsParser {

    private static final String TAG = "PermissionsParser";
    private static PermissionsParser permissionsParserInstance = null;
    private JSONArray permissions = null;

    protected PermissionsParser() {}

    public static synchronized PermissionsParser getInstance(){
        if(null == permissionsParserInstance){
            permissionsParserInstance = new PermissionsParser();
        }
        return permissionsParserInstance;
    }

    public JSONArray parsePermissions(Context context) {
        if (permissions == null) {
            try {
                final InputStream is = context.getAssets().open("permissions.json");
                final int size = is.available();
                final byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                final String json = new String(buffer, "UTF-8");
                permissions = new JSONArray(json);
            } catch (Exception ex) {
                permissions = new JSONArray();
            }
        }
        Log.d(TAG, "permissions: " + permissions.toString());
        return permissions;
    }

}
