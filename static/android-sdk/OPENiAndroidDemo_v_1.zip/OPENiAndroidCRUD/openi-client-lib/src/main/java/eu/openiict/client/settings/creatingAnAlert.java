package eu.openiict.client.settings;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceFragment;
import android.preference.PreferenceGroup;
import android.preference.PreferenceScreen;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.apache.http.message.BasicHeader;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import eu.openiict.client.R;
import eu.openiict.client.api.SubscriptionApi;
import eu.openiict.client.async.OPENiAsync;
import eu.openiict.client.async.models.ICloudletIdResponse;
import eu.openiict.client.async.models.IOPENiAPiCall;
import eu.openiict.client.common.ApiException;
import eu.openiict.client.model.Permissions;
import eu.openiict.client.model.Subscription;
import eu.openiict.client.settings.utils.Constants;

public class creatingAnAlert extends PreferenceActivity  {

    private static final String TAG = "PreferenceActivity";
    private static OPENiAsync openi;
    private static String cloudletID = "";
    private static Context context;



    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.openi = OPENiAsync.instanceWithoutMenu(this);
        Log.d(TAG, "PreferenceActivity onCreate()");
        getFragmentManager().beginTransaction().replace(android.R.id.content, new CreateAlertFragment()).commit();
    }


    public static class CreateAlertFragment extends PreferenceFragment
            implements SharedPreferences.OnSharedPreferenceChangeListener {

        private ArrayList<CheckBoxPreference> checkboxes = new ArrayList<CheckBoxPreference>();
        private String GCMID = "";
        GoogleCloudMessaging gcm;
        String regid;
        private SubscriptionApi subscriptionApi = new SubscriptionApi();
        private boolean IS_READY = false;
        private ProgressDialog progress;
        final ArrayList<Preference> allCheckBoxes = new ArrayList<Preference>();

        private JSONArray JsonSubscriptionArray = null;


        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            context = getActivity();
            progress = new ProgressDialog(context);
            if (PermissionsActivity.isOnline(getActivity())) {

                addPreferencesFromResource(R.xml.alerts);
                getGCMID(context);
                permsFiltering();
                getCurrentAlerts();
                //filterSettings();
            } else {
                Toast.makeText(getActivity(), "No internet", Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public void onResume() {
            creatingAnAlert.openi = OPENiAsync.instance(getActivity().getApplicationContext());
            super.onResume();
            getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
        }

        @Override
        public void onPause() {
            super.onPause();
            getPreferenceScreen().getSharedPreferences()
                    .unregisterOnSharedPreferenceChangeListener(this);
        }

        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {

        }

        private String getGCMID(Context context) {
//        if (GCMID.isEmpty()) {
//            SharedPreferences prefs = getSharedPreferences("gcm", Context.MODE_PRIVATE);
//            GCMID = prefs.getString("gcmID", "");
//
//        }
            if (GCMID.isEmpty()) {
                final String SENDER_ID = "844481426265";//"577101183835";
                new AsyncTask<String, String, String>() {
                    @Override
                    protected String doInBackground(String... params) {
                        String msg = "";
                        try {
                            if (gcm == null) {
                                gcm = GoogleCloudMessaging.getInstance(getActivity());
                            }
                            regid = gcm.register(SENDER_ID);
                            msg = "Device registered, registration ID=" + regid;

                        } catch (Exception ex) {
                            msg = "Error :" + ex.getMessage();
                        }
                        return msg;
                    }

                    @Override
                    protected void onPostExecute(String msg) {
                        Log.d(TAG, "regid: " + regid);
                    }
                }.execute("", "", "");
            }
            return GCMID;
        }

        private void getCurrentAlerts(){


            progress.show();

            BasicHeader[] headers = {
                    new BasicHeader("Authorization", openi.getPref("security_token"))
            };

            AsyncHttpClient client = new AsyncHttpClient();
            client.get(getActivity(), Constants.BASE_URL + "/api/v1/subscription/"+ Constants.API_KEY,
                    headers,
                    null,
                    new AsyncHttpResponseHandler() {
                        @Override
                        public void onSuccess(int statusCode, org.apache.http.Header[] headers, byte[] responseBody) {
                            String response = new String(responseBody);
                            Log.i("--GET SUBSCRIPTIONS",response);
                            try {
                                JsonSubscriptionArray = new JSONArray(response);
                                Log.i("jsonarray",JsonSubscriptionArray.toString());
                                setupCheckBoxes(JsonSubscriptionArray);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onFailure(int statusCode, org.apache.http.Header[] headers, byte[] responseBody, Throwable error) {
                            JsonSubscriptionArray = null;
                            progress.hide();
                            Toast.makeText(getActivity(),getActivity().getString(R.string.error_reading_alerts),Toast.LENGTH_LONG);
                        }

                    });
            getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
        }

        private void setupCheckBoxes(JSONArray JsonPermissionsArray) {

            getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);


            PreferenceScreen preferenceScreen = getPreferenceScreen();
            for (int i = 0; i < preferenceScreen.getPreferenceCount(); i++) {

                PreferenceGroup currentPreference = (PreferenceGroup) preferenceScreen.getPreference(i);
                if (currentPreference.getKey().equals("openi_opera_user_profile")) {
                    continue;
                }

                for (int j = 0; j < currentPreference.getPreferenceCount(); j++) {

                    Object p = currentPreference.getPreference(j);
                    if (p instanceof CheckBoxPreference) {
                        String key = ((CheckBoxPreference) p).getKey().split(Constants.ALERT_PREFIX)[1];
                        CheckBoxPreference check = (CheckBoxPreference) p;
                        if (JsonPermissionsArray.toString().toLowerCase().contains(key.toLowerCase())) {
                            check.setChecked(true);
                        } else {
                            check.setChecked(false);
                        }
                    }

                }
            }
            progress.hide();
        }

        private void setNotification(String type_id, String cloudletid, final boolean isPost) {
            final List<Subscription> subscriptionsList = new ArrayList<Subscription>();
            final Subscription subscription = new Subscription();
            subscription.setCloudletid(cloudletid);
            String data = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            data = data + " " ;
            subscription.setTypeid(type_id);
            subscription.setEndpoint(regid);
            subscription.setNotificationType("GCM");
            subscription.setData(data);
            subscription.setObjectid("");
            subscriptionsList.add(subscription);
            Log.d(TAG, "posting subscription");
            Log.d(TAG, "cloudletID: " + subscription.getCloudletid());
            Log.d(TAG, "Typeid: " + subscription.getTypeid());
            Log.d(TAG, "Endpoint: " + subscription.getEndpoint());
            Log.d(TAG, "NotificationType: " + subscription.getNotificationType());
            Log.d(TAG, "NotificationData: " + subscription.getData());
            Log.d(TAG, "NotificationObjectid: " + subscription.getObjectid());
//        final boolean toPost = isPost;
            openi.execOpeniApiCall(new IOPENiAPiCall() {
                @Override
                public String doProcess(String authToken) {
                    String result = "";
                    try {
                        if (isPost) {
                            Log.d(TAG, "add");
                            result = subscriptionApi.addSubscription(subscription, authToken);
                        } else {
                            Log.d(TAG, "remove");
                            result = subscriptionApi.removeSubscription();
                        }
                        return result;
                    } catch (ApiException e) {
                        e.printStackTrace();
                        return "error";
                    }

                }

                @Override
                public void onSuccess(Object object) {
                    Log.d(TAG, "success" + object);
                    progress.dismiss();
                }

                @Override
                public void onPermissionDenied() {
                    Log.d(TAG, "Permission Denied");
                    progress.dismiss();
                }

                @Override
                public void onFailure(String message) {
                    Log.d(TAG, "error subsription " + message);
                    progress.dismiss();
                }


            });
        }

        private void prepareNotification(final String type_id, final boolean isPost) {
            if (cloudletID.isEmpty()) {
                openi.getCloudletID(new ICloudletIdResponse() {
                    @Override
                    public void onSuccess(String cloudletid) {
                        Log.d(TAG, "Got cloudletid: " + cloudletid);
                        cloudletID = cloudletid;
                        setNotification(type_id, cloudletID, isPost);
                    }

                    @Override
                    public void onPermissionDenied() {
                        Log.d(TAG, "Permission Denied");
                        progress.dismiss();
                    }

                    @Override
                    public void onFailure(String error) {
                        Log.d(TAG, "failed: " + error);
                        progress.dismiss();
                    }


                });
            } else {
                setNotification(type_id, cloudletID, isPost);
            }
        }

        final Preference.OnPreferenceClickListener listener =
                new Preference.OnPreferenceClickListener() {

                    @Override
                    public boolean onPreferenceClick(Preference preference) {
                        Log.d(TAG, "onPreferenceClick()");
                        progress.show();
                        final CheckBoxPreference pref = (CheckBoxPreference) preference;
                        Log.d(TAG, "current value: " + pref.isChecked());
                        final boolean isChecked = pref.isChecked();
                        try {
                            AlertDialog.Builder alertDialogBuilder =
                                    new AlertDialog.Builder(getActivity());

                            alertDialogBuilder.setTitle("Are you sure?");

                            if (isChecked) {
                                alertDialogBuilder
                                        .setMessage("You want to create an alert?");
                            } else {
                                alertDialogBuilder
                                        .setMessage("You want to delete the alert?");
                            }
                            final String type_id = pref.getKey().split(Constants.ALERT_PREFIX)[1];
                            alertDialogBuilder
                                    .setCancelable(false)
                                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            Log.i(TAG, " type: " + type_id);
                                            prepareNotification(type_id, true);
                                        }
                                    })
                                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            pref.setChecked(!pref.isChecked());

                                            Log.i(TAG, " type: " + type_id);
                                            prepareNotification(type_id, false);
                                            dialog.cancel();
                                        }
                                    });
                            AlertDialog alertDialog = alertDialogBuilder.create();
                            alertDialog.show();
                        } catch (Exception exception) {
                            Log.d(TAG, exception.toString());
                        }
                        return true;
                    }

                };


  /*       private void filterSettings() {
            Log.d(TAG, "filterSettings()");

            JSONArray jsonArray;
            Set<String> permissionTypes = new HashSet<String>();
            // read the app permission
            try {
                jsonArray = PermissionsParser.getInstance().parsePermissions(context);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject permission = jsonArray.getJSONObject(i);
                    String typeId = permission.getString("ref");
                    permissionTypes.add("alert_" + typeId);
                }
                Iterator<String> permissionTypesIterator = permissionTypes.iterator();
                while (permissionTypesIterator.hasNext()) {
                    try {
                        String currentTypeId = permissionTypesIterator.next();
                        allCheckBoxes.add(findPreference(currentTypeId));
                    } catch (Exception ex) {
                        Log.d(TAG, "error in while loop: " + ex.toString());
                    }
                }
            } catch (Exception ex) {
                Log.d(TAG, "error parsing permissions");
                Log.e(TAG, ex.toString());
            }
            PreferenceScreen preferenceScreen = getPreferenceScreen();
            boolean tobeRemoved = false;
            Log.d(TAG, "permissionTypes: " + permissionTypes.toString());
            ArrayList<Preference> removeGroups = new ArrayList<Preference>();
            HashMap<String, List<Preference>> removeTypes = new HashMap<String, List<Preference>>();
            for (int i = 0; i < preferenceScreen.getPreferenceCount(); i++) {

                PreferenceGroup currentPreference = (PreferenceGroup) preferenceScreen.getPreference(i);
                if (currentPreference.getKey().equals("openi_opera_user_profile")) {
                    continue;
                }
                tobeRemoved = true;
                ArrayList<Preference> tmpRemoveTypes = new ArrayList<Preference>();
                for (int j = 0; j < currentPreference.getPreferenceCount(); j++) {
                    Object p = currentPreference.getPreference(j);
                    if (p instanceof CheckBoxPreference) {
                        String key = ((CheckBoxPreference) p).getKey();
                        Log.i(TAG, " key: " + key);
                        if (permissionTypes.contains(key)) {
                            tobeRemoved = false;
                            String title = (((CheckBoxPreference) p).getTitle()).toString();
                            //((CheckBoxPreference) p).setChecked(true);
                        } else {
                            // filter out the types
//                        Log.d(TAG, ":: " + ((Preference) p).getKey());
//                        currentPreference.removePreference((Preference) p); // move out of the loop
                            tmpRemoveTypes.add((Preference) p);
                        }
                    }
                }
                removeTypes.put(currentPreference.getKey(), tmpRemoveTypes);
//            tobeRemoved = false; // delete line todo
                if (tobeRemoved == true) {
                    // filter out the first grouping level of the types // move out of the loop
                    removeGroups.add(preferenceScreen.getPreference(i));
                } else {
                    for (int j = 0; j < currentPreference.getPreferenceCount(); j++) {
                        final Object p = currentPreference.getPreference(j);
                        if (p instanceof CheckBoxPreference) {
                            final CheckBoxPreference checkBoxPreference = ((CheckBoxPreference) p);
                            final String title = checkBoxPreference.getTitle().toString();
                            //updateCheckbox(checkBoxPreference);
                        }
                    }
                }
                if (i >= preferenceScreen.getPreferenceCount() - 1) {
//                notifyPermissionUpdate = false;
                }
            }
            IS_READY = true;
            progress.dismiss();
            removePreferences(preferenceScreen, removeGroups, removeTypes);
            //addPreferencesFromResource(R.xml.preferences_opera);
        }

       private void removePreferences(PreferenceScreen preferenceScreen,
                                       ArrayList<Preference> removeGroups,
                                       HashMap<String, List<Preference>> removeTypes) {

            Iterator iterRemoveTypes = removeTypes.entrySet().iterator();
            while (iterRemoveTypes.hasNext()) {
                HashMap.Entry pair = (HashMap.Entry) iterRemoveTypes.next();
                PreferenceGroup parent = (PreferenceGroup) preferenceScreen
                        .findPreference((CharSequence) pair.getKey());
                List<Preference> prefList = (List<Preference>) pair.getValue();
                int counter = 0;
                while (prefList.size() > counter) {
                    parent.removePreference(prefList.get(counter));
                    counter++;
                }
            }
            Iterator iterRemoveGroups = removeGroups.iterator();
            while (iterRemoveGroups.hasNext()) {
                preferenceScreen.removePreference((Preference) iterRemoveGroups.next());
            }
        }*/


        private void permsFiltering() {
            Log.d(TAG, "permsFiltering()");
            JSONArray jsonArray;
            Set<String> permissionTypes = new HashSet<String>();
            try {
                final InputStream is = context.getAssets().open("permissions.json");
                final int size = is.available();
                final byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                final String json = new String(buffer, "UTF-8");
                jsonArray = new JSONArray(json);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject permission = jsonArray.getJSONObject(i);
                    String typeId = permission.getString("ref");
                    permissionTypes.add(Constants.ALERT_PREFIX + typeId);
                }
                Iterator<String> permissionTypesIterator = permissionTypes.iterator();
                while (permissionTypesIterator.hasNext()) {
                    try {
                        String currentTypeId = permissionTypesIterator.next();
                        //allCheckBoxes.add(findPreference(currentTypeId));
                    } catch (Exception ex) {
                        Log.d(TAG, "error in while loop: " + ex.toString());
                    }
                }
            } catch (Exception ex) {
                Log.d(TAG, "error parsing permissions");
                Log.e(TAG, ex.toString());
            }
            PreferenceScreen preferenceScreen = getPreferenceScreen();
            boolean tobeRemoved = false;
            Log.d(TAG, "permissionTypes: " + permissionTypes.toString());
            ArrayList<Preference> removeGroups = new ArrayList<Preference>();
            HashMap<String, List<Preference>> removeTypes = new HashMap<String, List<Preference>>();
            for (int i = 0; i < preferenceScreen.getPreferenceCount(); i++) {
                PreferenceGroup currentPreference = (PreferenceGroup) preferenceScreen.getPreference(i);
                tobeRemoved = true;
                ArrayList<Preference> tmpRemoveTypes = new ArrayList<Preference>();
                for (int j = 0; j < currentPreference.getPreferenceCount(); j++) {
                    Object p = currentPreference.getPreference(j);
                    if (p instanceof CheckBoxPreference) {
                        String key = ((CheckBoxPreference) p).getKey();
                        if (permissionTypes.contains(key)) {
                            tobeRemoved = false;
                            String title = (((CheckBoxPreference) p).getTitle()).toString();
                            ((CheckBoxPreference) p).setChecked(false);
                            checkboxes.add((CheckBoxPreference) p);
                        } else {
                            tmpRemoveTypes.add((Preference) p);
                        }
                    }
                }
                removeTypes.put(currentPreference.getKey(), tmpRemoveTypes);
                if (tobeRemoved == true) {
                    removeGroups.add(preferenceScreen.getPreference(i));
                }
            }

            Iterator iterRemoveTypes = removeTypes.entrySet().iterator();
            while (iterRemoveTypes.hasNext()) {
                HashMap.Entry pair = (HashMap.Entry) iterRemoveTypes.next();
                PreferenceGroup parent = (PreferenceGroup) preferenceScreen
                        .findPreference((CharSequence) pair.getKey());
                List<Preference> prefList = (List<Preference>) pair.getValue();
                int counter = 0;
                while (prefList.size() > counter) {
                    parent.removePreference(prefList.get(counter));
                    counter++;
                }
            }

            Iterator iterRemoveGroups = removeGroups.iterator();
            while (iterRemoveGroups.hasNext()) {
                preferenceScreen.removePreference((Preference) iterRemoveGroups.next());
            }

            Log.d(TAG, "checkboxes array: " + checkboxes.toString());

            Iterator<CheckBoxPreference> iteratorCheckBoxes = checkboxes.iterator();
            while (iteratorCheckBoxes.hasNext()) {
                final CheckBoxPreference cpref = iteratorCheckBoxes.next();
                Log.d(TAG, ":: " + cpref.getTitle());
                final Preference pref = (Preference) cpref;
                openi.execOpeniApiCall(new IOPENiAPiCall() {
                    List<Permissions> currentPermissions;

                    @Override
                    public String doProcess(String authToken) {
                        SubscriptionApi subscriptionApi = new SubscriptionApi();
                        try {
                            String sub = subscriptionApi.getSubscriptionsByCloudlet(authToken);
                            return sub;
                        } catch (ApiException e) {
                            e.printStackTrace();
                            return null;
                        }
                    }

                    @Override
                    public void onSuccess(Object sub) {
                        String s = (String) sub;
                        Log.d(TAG, "sub: " + sub.getClass().toString());
                        Log.d(TAG, "k: " + pref.getKey());
                        Log.d(TAG, "s: " + s);
                        boolean isChecked = s.contains(pref.getKey());
                        Log.d(TAG, "sub: " + isChecked);
                        if (isChecked) {
                            cpref.setChecked(true);
                        }
                    }

                    @Override
                    public void onPermissionDenied() {
                        Log.e(TAG, "Permission Denied ");
                    }

                    @Override
                    public void onFailure(String message) {
                        Log.e(TAG, "Failed " + message);
                    }


                });
                pref.setOnPreferenceClickListener(listener);
            }


        }
    }
}
