package eu.openiict.client.settings;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceFragment;
import android.preference.PreferenceGroup;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;
import android.util.Log;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import eu.openiict.client.R;
import eu.openiict.client.api.PermissionsApi;
import eu.openiict.client.async.OPENiAsync;
import eu.openiict.client.async.models.ICloudletIdResponse;
import eu.openiict.client.model.Permissions;
import eu.openiict.client.settings.utils.Constants;
import eu.openiict.client.settings.utils.PermissionsParser;

public class PermissionsActivity extends PreferenceActivity {
    private static OPENiAsync openi;


    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.openi = OPENiAsync.instanceWithoutMenu(this);
        getFragmentManager().beginTransaction().replace(android.R.id.content, new PermissionsFragment()).commit();
    }


    public static class PermissionsFragment extends PreferenceFragment
            implements SharedPreferences.OnSharedPreferenceChangeListener {

        Context context;
        private PermissionsApi permissionsApi = new PermissionsApi();
        private String cloudletID = null;
        private static final String TAG = "PermissionsActivity";
        private boolean IS_READY = false;
        //    private boolean notifyPermissionUpdate = false;
        final ArrayList<Preference> allCheckBoxes = new ArrayList<Preference>();
        private ProgressDialog progress;

        List<Permissions> currentPermissions = new ArrayList<>();
        private JSONArray JsonPermissionsArray = null;

        private Map<String, ?> allEntries;


        @Override
        public void onCreate(Bundle savedInstanceState) {
            Log.d(TAG, "onCreate()");
            super.onCreate(savedInstanceState);
            //addPreferencesFromResource(R.xml.preferences_opera);
            if (isOnline(getActivity())) {
                addPreferencesFromResource(R.xml.preferences);
                execute();
            }

            allEntries = PreferenceManager.getDefaultSharedPreferences(getActivity()).getAll();


            context = getActivity();
        }


        @Override
        public void onResume() {
            PermissionsActivity.openi = OPENiAsync.instance(getActivity().getApplicationContext());
            super.onResume();
            getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
/*            if (isOnline(getActivity())) {
                getCurrentPermissions();
            }*/
            //getCurrentPermissions();


        }



        private void getCloudletIdAndFilterSettings() {
            openi.getCloudletID(new ICloudletIdResponse() {
                @Override
                public void onSuccess(String cloudletid) {
                    Log.d(TAG, "Got cloudletid: " + cloudletid);
                    cloudletID = cloudletid;
                    filterSettings(cloudletid);
                    getCurrentPermissions();
                }

                @Override
                public void onPermissionDenied() {
                    Log.d(TAG,"Permissions Denied");
                }

                @Override
                public void onFailure(String error) {
                    Log.d(TAG, "failed: "+error);
                }


            });
        }

        private void execute() {
            Log.d(TAG, "execute()");
            progress = new ProgressDialog(getActivity());
            progress.show();
            if (cloudletID == null) {
                Log.d(TAG, "cloudletID == null");
                getCloudletIdAndFilterSettings();
            } else {
                Log.d(TAG, "cloudletID !== null");
                filterSettings(cloudletID);
                getCurrentPermissions();
            }
        }

        private void setupCheckBoxes(JSONArray JsonPermissionsArray){

            getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);


            PreferenceScreen preferenceScreen = getPreferenceScreen();
            for (int i = 0; i < preferenceScreen.getPreferenceCount(); i++) {

                PreferenceGroup currentPreference = (PreferenceGroup) preferenceScreen.getPreference(i);
                if (currentPreference.getKey().equals("openi_opera_user_profile")) {
                    continue;
                }

                for (int j = 0; j < currentPreference.getPreferenceCount(); j++) {

                    Object p = currentPreference.getPreference(j);
                    if (p instanceof CheckBoxPreference) {
                        String key = ((CheckBoxPreference) p).getKey();
                        CheckBoxPreference check = (CheckBoxPreference)p;
                        if(JsonPermissionsArray.toString().toLowerCase().contains(key.toLowerCase())) {
                            check.setChecked(true);
                        }else {
                            check.setChecked(false);
                        }
                    }

                }
            }



/*            for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
                if(JsonPermissionsArray.toString().toLowerCase().contains(entry.getKey() .toLowerCase())){
                    Preference pref = findPreference(entry.getKey());
                    if (pref instanceof CheckBoxPreference) {
                        CheckBoxPreference check = (CheckBoxPreference)pref;
                        check.setChecked(true);
                    }
                }else{
                    Preference pref = findPreference(entry.getKey());
                    if (pref instanceof CheckBoxPreference) {
                        CheckBoxPreference check = (CheckBoxPreference)pref;
                        check.setChecked(false);
                    }
                }
            }*/
            getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
        }


        private void getCurrentPermissions(){


            BasicHeader[] headers = {
                    new BasicHeader("Authorization", openi.getPref("security_token"))
            };

            AsyncHttpClient client = new AsyncHttpClient();
            client.get(getActivity(), Constants.BASE_URL + "/api/v1/permissions/"+ Constants.API_KEY,
                    headers,
                    null,
                    new AsyncHttpResponseHandler() {
                        @Override
                        public void onSuccess(int statusCode, org.apache.http.Header[] headers, byte[] responseBody) {
                            String response = new String(responseBody);
                            Log.i("--GET PERMISSIONS",response);
                            try {
                                JsonPermissionsArray = new JSONArray(response);
                                setupCheckBoxes(JsonPermissionsArray);
                                //for (int i=0; i < JsonPermissionsArray.length(); i++) {
                                 //   JSONObject js = JsonPermissionsArray.getJSONObject(i);

                                  Log.i("jsonarray",JsonPermissionsArray.toString());
/*                                p.setRef(js.getString("ref"));
                                p.setAccessLevel(js.getString("access_level"));
                                p.setAccessType(js.getString("access_type"));
                                p.setType(js.getString("type"));
                                currentPermissions.add(p);*/
                                //}
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }

                        @Override
                        public void onFailure(int statusCode, org.apache.http.Header[] headers, byte[] responseBody, Throwable error) {
                            JsonPermissionsArray = null;
                        }

                    });


        }

        private void postPermissions(String json){

            BasicHeader[] headers = {
                    new BasicHeader("Authorization", openi.getPref("security_token"))
            };

            StringEntity entity = null;
            try {
                entity = new StringEntity(json);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

            AsyncHttpClient client = new AsyncHttpClient();
            client.post(getActivity(),  Constants.BASE_URL +"/api/v1/permissions/" + Constants.API_KEY,
                    headers,
                    entity,
                    null,
                    new AsyncHttpResponseHandler() {
                        @Override
                        public void onSuccess(int statusCode, org.apache.http.Header[] headers, byte[] responseBody) {
                            String response = new String(responseBody);
                            Log.i("--POST PERMISSIONS", response);
                            progress.dismiss();

                        }

                        @Override
                        public void onFailure(int statusCode, org.apache.http.Header[] headers, byte[] responseBody, Throwable error) {
                            Log.e("--FAILED POST", new String(responseBody));
                            progress.dismiss();
                        }

                    });


        }





        private void updateCheckbox(CheckBoxPreference checkboxPreference) {


        /*    final CheckBoxPreference cbp = checkboxPreference;
            openi.execOpeniApiCall(new IOPENiAPiCall() {
                List<Permissions> currentPermissions;

                @Override
                public Object doProcess(String authToken) {
                    try {
                        currentPermissions = permissionsApi.getPermissions(authToken);
                        return currentPermissions;
                    } catch (ApiException e) {
                        e.printStackTrace();
                        return null;
                    }
                }

                @Override
                public void onSuccess(Object object) {
                    //cbp.setChecked(false);
           /*         ListIterator<Permissions> iterator = ((List<Permissions>) object)
                            .listIterator();
                    while (iterator.hasNext()) {
                        Permissions permission = iterator.next();
                        String permissionReference = permission.getRef();
                        String checkBoxID = cbp.getKey();
                        boolean isMatched = checkBoxID.equals(permissionReference);
                        if (isMatched) {
                            //cbp.setChecked(true);
                        }
                    }
                    Log.i(TAG,"---Current permissions: "+object.toString());
                }

                @Override
                public void onPermissionDenied() {

                }

                @Override
                public void onFailure(String error) {
                    Log.d(TAG, "Failed: "+error);
                }
            });
    */
        }

        private void removePreferences(PreferenceScreen preferenceScreen,
                                       ArrayList<Preference> removeGroups,
                                       HashMap<String, List<Preference>> removeTypes) {

            Iterator iterRemoveTypes = removeTypes.entrySet().iterator();
            while (iterRemoveTypes.hasNext()) {
                HashMap.Entry pair = (HashMap.Entry) iterRemoveTypes.next();
                PreferenceGroup parent = (PreferenceGroup) preferenceScreen
                        .findPreference((CharSequence) pair.getKey());
                List<Preference> prefList = (List<Preference>) pair.getValue();
                int counter = 0;
                while (prefList.size() > counter) {
                    parent.removePreference(prefList.get(counter));
                    counter++;
                }
            }
            Iterator iterRemoveGroups = removeGroups.iterator();
            while (iterRemoveGroups.hasNext()) {
                preferenceScreen.removePreference((Preference) iterRemoveGroups.next());
            }
        }



        private void filterSettings(final String cloudletid) {
            Log.d(TAG, "filterSettings()");
            if (cloudletid.isEmpty()) {
                return;
            }
            JSONArray jsonArray;
            Set<String> permissionTypes = new HashSet<String>();
            // read the app permission
            try {
                jsonArray = PermissionsParser.getInstance().parsePermissions(context);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject permission = jsonArray.getJSONObject(i);
                    String typeId = permission.getString("ref");
                    permissionTypes.add(typeId);
                }
                Iterator<String> permissionTypesIterator = permissionTypes.iterator();
                while (permissionTypesIterator.hasNext()) {
                    try {
                        String currentTypeId = permissionTypesIterator.next();
                        allCheckBoxes.add(findPreference(currentTypeId));
                    } catch (Exception ex) {
                        Log.d(TAG, "error in while loop: " + ex.toString());
                    }
                }
            } catch (Exception ex) {
                Log.d(TAG, "error parsing permissions");
                Log.e(TAG, ex.toString());
            }
            PreferenceScreen preferenceScreen = getPreferenceScreen();
            boolean tobeRemoved = false;
            Log.d(TAG, "permissionTypes: " + permissionTypes.toString());
            ArrayList<Preference> removeGroups = new ArrayList<Preference>();
            HashMap<String, List<Preference>> removeTypes = new HashMap<String, List<Preference>>();
            for (int i = 0; i < preferenceScreen.getPreferenceCount(); i++) {

                PreferenceGroup currentPreference = (PreferenceGroup) preferenceScreen.getPreference(i);
                if(currentPreference.getKey().equals("openi_opera_user_profile")){
                    continue;
                }
                tobeRemoved = true;
                ArrayList<Preference> tmpRemoveTypes = new ArrayList<Preference>();
                for (int j = 0; j < currentPreference.getPreferenceCount(); j++) {
                    Object p = currentPreference.getPreference(j);
                    if (p instanceof CheckBoxPreference) {
                        String key = ((CheckBoxPreference) p).getKey();
                        if (permissionTypes.contains(key)) {
                            tobeRemoved = false;
                            String title = (((CheckBoxPreference) p).getTitle()).toString();
                            //((CheckBoxPreference) p).setChecked(true);
                        } else {
                            // filter out the types
//                        Log.d(TAG, ":: " + ((Preference) p).getKey());
//                        currentPreference.removePreference((Preference) p); // move out of the loop
                            tmpRemoveTypes.add((Preference) p);
                        }
                    }
                }
                removeTypes.put(currentPreference.getKey(), tmpRemoveTypes);
//            tobeRemoved = false; // delete line todo
                if (tobeRemoved == true) {
                    // filter out the first grouping level of the types // move out of the loop
//                Preference pp = preferenceScreen.getPreference(i);
//                preferenceScreen.removePreference(pp);
                    removeGroups.add(preferenceScreen.getPreference(i));
                } else {
                    for (int j = 0; j < currentPreference.getPreferenceCount(); j++) {
                        final Object p = currentPreference.getPreference(j);
                        if (p instanceof CheckBoxPreference) {
                            final CheckBoxPreference checkBoxPreference = ((CheckBoxPreference) p);
                            final String title = checkBoxPreference.getTitle().toString();
                            //updateCheckbox(checkBoxPreference);
                        }
                    }
//                // disable checkboxes that correspond to types for which there are no cloudlet objects
/*                    for (int j = 0; j < currentPreference.getPreferenceCount(); j++) {
                        final Object p = currentPreference.getPreference(j);
                        if (p instanceof CheckBoxPreference) {
                            final CheckBoxPreference checkBoxPreference = ((CheckBoxPreference) p);
                            final String title = checkBoxPreference.getTitle().toString();
//                        updateCheckbox(checkBoxPreference);
                            final String typeID = checkBoxPreference.getKey();
                            Log.d(TAG, "c: " + cloudletid);
                            Log.d(TAG, "t: " + typeID);
                            try {
                                openi.execOpeniApiCall(new IOPENiAPiCall() {
                                    @Override
                                    public OPENiObjectList doProcess(String authToken) {
                                        Log.d(TAG, "a: " + authToken);
                                        try {
                                            ObjectsApi oapi = new ObjectsApi();
                                            return oapi.getObjects(
                                                    cloudletid,
                                                    new Integer(0),
                                                    new Integer(30),
                                                    typeID,
                                                    false,
                                                    "", "", "",
                                                    authToken);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                            return null;
                                        }
                                    }

                                    @Override
                                    public void onSuccess(Object objects) {
                                        Log.d(TAG, "" + ((OPENiObjectList) objects).getResult().toString());
                                        boolean isEmpty = ((OPENiObjectList) objects).getResult()
                                                .isEmpty();
                                        Log.d(TAG, "is empty: " + isEmpty);
                                        Log.d(TAG, ":" + checkBoxPreference.getKey());
                               *//*         if (isEmpty) {
                                            ((CheckBoxPreference) p).setChecked(true);
                                           // ((CheckBoxPreference) p).setEnabled(true);
                                        } else {
                                            updateCheckbox(checkBoxPreference);
                                        }*//*
                                        updateCheckbox(checkBoxPreference);
                                    }

                                    @Override
                                    public void onFailure() {

                                        Log.d(TAG, "Fail getting cards");
                                    }
                                });
                            } catch (Exception ex) {
                                Log.d(TAG, "error: " + ex.toString());
                            }
                        }
                    }*/
                }
                if (i >= preferenceScreen.getPreferenceCount() - 1) {
//                notifyPermissionUpdate = false;
                }
            }
            IS_READY = true;
            progress.dismiss();
            removePreferences(preferenceScreen, removeGroups, removeTypes);
            //addPreferencesFromResource(R.xml.preferences_opera);
        }



        @Override
        public void onPause() {
            super.onPause();
            getPreferenceScreen().getSharedPreferences()
                    .unregisterOnSharedPreferenceChangeListener(this);
        }




        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, final String key) {
            progress.show();

            openi.setPrefBool(key, sharedPreferences.getBoolean(key, true));
         /* */
            if (!IS_READY || !isOnline(getActivity())) {
                return;
            }
            Log.d(TAG, "onSharedPreferenceChanged");

            allEntries = PreferenceManager.getDefaultSharedPreferences(getActivity()).getAll();



            StringBuilder JsonToPost = new StringBuilder("[");



            for (int i=0; i < JsonPermissionsArray.length(); i++) {
                JSONObject js;
                try {
                    js = JsonPermissionsArray.getJSONObject(i);
                    Log.e(TAG,js.toString());
                    if(js==null) { continue; }
                } catch (JSONException e) { e.printStackTrace(); continue; }

                boolean existsInPref = false;
                for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
                    if(entry.getKey().toString().toLowerCase().contains("alert")){continue;}
                    Log.d("map values", entry.getKey() + ": " + entry.getValue().toString());
                    boolean doesExistInCurrentPref = false;
                    try {
                        doesExistInCurrentPref = js.getString("ref").equals(entry.getKey());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    boolean isTrue=false;
                    if (entry.getValue() instanceof  Boolean) {
                        Log.d("___Boolean","instance");
                        isTrue = (Boolean) entry.getValue();
                    } else if(entry.getValue() instanceof String) {
                        Log.d("___String","instance");
                        isTrue ="true".equals(entry.getValue());
                    }


                    Log.d("isTrue",String.valueOf(isTrue));
                 //   if ("true".equals(entry.getValue()) || "false".equals(entry.getValue())) {
                 //        isTrue = (Boolean) entry.getValue();
                  //  }
                    Log.d("doesExistInCurrentPref",String.valueOf(doesExistInCurrentPref));
                    if(doesExistInCurrentPref){
                        existsInPref = true;
                        if (isTrue) {
                            JsonToPost.append(js.toString());
                            JsonToPost.append(",");
                        }
                    }
                }
                if (!existsInPref) {
                    JsonToPost.append(js.toString());
                    JsonToPost.append(",");
                }
            }

            Log.d("before", JsonToPost.toString());



            // An einai true kai den exei hdh mpei sto Json string
            if (sharedPreferences.getBoolean(key, false) && !JsonToPost.toString().contains(key)) {
                for (int i=0;i<4;i++) {
                    JSONObject newpermission = new JSONObject();
                    try {
                        newpermission.put("ref", key);
                        newpermission.put("type", "type");
                        newpermission.put("access_level", "APP");
                        switch (i) {
                            case 0:
                                newpermission.put("access_type", "CREATE");
                                break;
                            case 1:
                                newpermission.put("access_type", "READ");
                                break;
                            case 2:
                                newpermission.put("access_type", "UPDATE");
                                break;
                            case 3:
                                newpermission.put("access_type", "DELETE");
                                break;
                        }
                        JsonToPost.append(newpermission.toString());
                        JsonToPost.append(",");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            JsonToPost.deleteCharAt(JsonToPost.length()-1);//diagrafh teleutaiou comma

            JsonToPost.append("]");

            Log.i(" jsontoPost: ", JsonToPost.toString());
            postPermissions(JsonToPost.toString());


        }
    }

    public static boolean isOnline(Context ctx) {
        ConnectivityManager connMgr = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnected());
    }
}