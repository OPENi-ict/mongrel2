package eu.openiict.client.settings;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import eu.openiict.client.R;
import eu.openiict.client.async.OPENiAsync;

public class SettingsActivity extends Activity {
    private final static String TAG = "SettingsActivity";
    private OPENiAsync openi = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate()");
        super.onCreate(savedInstanceState);
        //OPENiAsync.init("c0e73b305fda9fa7510bfb08c49870da","d14dc301f086ba6615303f56458fec564a72cfe7a82054b908b13b228405cad7",this, "permissions.json");
        openi = OPENiAsync.instanceWithoutMenu(getApplicationContext());
        setContentView(R.layout.activity_settings);

        final Button buttonPermissions = (Button) findViewById(R.id.permissions);
        buttonPermissions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "permissions");
                Intent intent = new Intent(v.getContext(), PermissionsActivity.class);
                startActivity(intent);
            }
        });

        final Button buttonAlerts = (Button) findViewById(R.id.creatingAnAlert);
        buttonAlerts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "subscription");
                Intent intent = new Intent(v.getContext(), creatingAnAlert.class);
                startActivity(intent);
            }
        });

        final Button buttonNotifications = (Button) findViewById(R.id.notifications);
        buttonNotifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "notifications");
                Intent intent = new Intent(v.getContext(), Notifications.class);
                startActivity(intent);
            }
        });



    }

    @Override
    protected void onResume() {
        Log.d(TAG, "onResume()");
        //OPENiAsync.init("c0e73b305fda9fa7510bfb08c49870da","d14dc301f086ba6615303f56458fec564a72cfe7a82054b908b13b228405cad7",this, "permissions.json");
        openi = OPENiAsync.instance(this);
        super.onResume();
        //getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onPause() {
        Log.d(TAG, "onPause()");
        super.onPause();
        //getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
    }
}
