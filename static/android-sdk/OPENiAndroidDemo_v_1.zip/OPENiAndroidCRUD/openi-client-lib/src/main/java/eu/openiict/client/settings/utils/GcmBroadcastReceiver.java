package eu.openiict.client.settings.utils;

/**
 * Created by dconway on 12/01/15.
 */

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.util.Log;

import java.util.Iterator;

public class GcmBroadcastReceiver extends WakefulBroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        Log.d(": ", "onReceive");

        Bundle extras = intent.getExtras();

        for (String key : extras.keySet()) {
            Object value = extras.get(key);
            Log.d(": EXTRAS", String.format("%s %s (%s)", key,
                    value.toString(), value.getClass().getName()));
        }

        Intent msgrcv = new Intent("Msg");
        Iterator<String> it = extras.keySet().iterator();
        while (it.hasNext()) {
            Log.d("::", "key: " + it.next());
        }
        msgrcv.putExtra("from", extras.getString("from"));
        msgrcv.putExtra("collapse_key", extras.getString("collapse_key"));
        msgrcv.putExtra("object", extras.getString("object"));
        msgrcv.putExtra("type", extras.getString("type"));
        msgrcv.putExtra("date", extras.getString("date"));
        msgrcv.putExtra("cloudlet", extras.getString("cloudlet"));

//        msgrcv.putExtra("msg", extras.getString("msg"));
//        msgrcv.putExtra("fromu", extras.getString("fromu"));
//        msgrcv.putExtra("fromname", extras.getString("name"));

        LocalBroadcastManager.getInstance(context).sendBroadcast(msgrcv);
        // Explicitly specify that GcmMessageHandler will handle the intent.
        ComponentName comp = new ComponentName(context.getPackageName(),
                GcmMessageHandler.class.getName());

        // Start the service, keeping the device awake while it is launching.
        startWakefulService(context, (intent.setComponent(comp)));
        setResultCode(Activity.RESULT_OK);
    }
}
